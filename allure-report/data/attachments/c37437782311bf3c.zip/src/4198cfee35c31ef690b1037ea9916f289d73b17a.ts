

import {test, expect} from '@playwright/test'
import {POManager} from '../pageobjects/POManager'
import {validationLoginData} from '../test-data/login-data'
import {eventNameData, eventDateData, eventAddressData} from '../test-data/home-data'
import {eventsError, categories} from '../test-data/events-data'
const data = JSON.parse(JSON.stringify(require('../utils/test-data.json')))

test.describe('Event Page Tests', async() => {

    test.beforeEach(async({page}) => {
        await page.goto("https://eventhub.rahulshettyacademy.com/")
    })

    test.only('Verify and Search for matching event', async({page}) => {

        const poManager = new POManager(page)
        await poManager.loginPage.validLoginUsingUsernameAndPassword(data.username, data.password, validationLoginData.headerTextForEventsPage)
        await poManager.eventsPage.verifyEventsPage()
        await poManager.eventsPage.verifySearchEventAndMatch(eventNameData.eventName1)

    })

    test.only('Verify Not exisiting event not getting searched with error message', async({page}) => {

        const poManager = new POManager(page)
        await poManager.loginPage.validLoginUsingUsernameAndPassword(data.username, data.password, validationLoginData.headerTextForEventsPage)
        await poManager.eventsPage.verifyEventsPage()
        await poManager.eventsPage.verifyNotExistingEventWithError(eventNameData.notExisitingEventName, eventsError.notExisitingEventsError)
    })


    test.only('Verify user is able to search with partial event name', async({page}) => {

        const poManager = new POManager(page)
        await poManager.loginPage.validLoginUsingUsernameAndPassword(data.username, data.password, validationLoginData.headerTextForEventsPage)
        await poManager.eventsPage.verifyEventsPage()
        await poManager.eventsPage.verifySearchWithPartialEventName(eventNameData.partialEventName, eventNameData.eventName1, eventNameData.eventName2, eventNameData.eventName3)

    })

    test.only('Verify filter events and check the cards', async({page}) => {

        const poManager = new POManager(page)
        await poManager.loginPage.validLoginUsingUsernameAndPassword(data.username, data.password, validationLoginData.headerTextForEventsPage)
        await poManager.eventsPage.verifyEventsPage()
        await poManager.eventsPage.verifyWithFilterEvents(categories.category1, categories.category2, categories.category3, categories.category4, categories.category5, 
            eventNameData.eventName3, eventNameData.eventName2, eventNameData.eventName1)
   
    })

    test('Verify filter cities and check the cards', async({page}) => {

        const poManager = new POManager(page)
        await poManager.loginPage.validLoginUsingUsernameAndPassword(data.username, data.password, validationLoginData.headerTextForEventsPage)

        await page.locator("#nav-events").click()
        await expect(page.locator('.mb-8 h1')).toHaveText('Upcoming Events')

        const categorySelect = page.locator('select').nth(1)
        const cardTitles = page.locator("#event-card")

        const cities = [
            "Mumbai", 
            "Bangalore",
            "Delhi",
            "Hyderabad",
            "Chennai", 
            "Pune"
        ]

        for(const city of cities) {

            await categorySelect.selectOption(city)
            const count = await cardTitles.count()

            if(count > 0) {
                const titles = await cardTitles.locator('h3').allTextContents()

                if(city === 'Delhi') {
                    expect(titles).toContain(eventNameData.eventName1)

                }
                if(city === 'Hyderabad') {
                    expect(titles).toContain(eventNameData.eventName3)
                } else {
                    await expect(page.getByText(/no events found/i)).toBeVisible();
                }
            }
        }


    })

    test('Verify apply filter and clear filter working as expected', async({page}) => {

        const poManager = new POManager(page)
        await poManager.loginPage.validLoginUsingUsernameAndPassword(data.username, data.password, validationLoginData.headerTextForEventsPage)

        await page.locator("#nav-events").click()
        await expect(page.locator('.mb-8 h1')).toHaveText('Upcoming Events')

        const selectCategory = page.locator('select').nth(0)
        const selectCity = page.locator('select').nth(1)

        await selectCategory.selectOption("Conference")
        await selectCity.selectOption("Hyderabad")

        const cardTitles = page.locator("#event-card")

        await expect(cardTitles.first()).toBeVisible()
        expect(await cardTitles.count()).toBeGreaterThanOrEqual(1)
        await expect(cardTitles.locator('h3')).toHaveText(eventNameData.eventName3)
        await expect(cardTitles.locator('span.line-clamp-1').nth(0)).toHaveText(eventDateData.eventDate3)
        await expect(cardTitles.locator('span.line-clamp-1').nth(1)).toHaveText(eventAddressData.eventAddress3)

        await page.getByRole("button", {name: "Clear filters"}).click()

        await expect(cardTitles.first()).toBeVisible()
        expect(await cardTitles.count()).toBeGreaterThan(1)


    })
})

